import { useState, useMemo, useEffect } from 'react';
import {
  EnergySpecs,
  CustomerData,
  AdviceScope,
  BatteryProduct,
  HeatPumpProduct,
} from './types';
import {
  HYXIPOWER_BATTERIES,
  VAILLANT_HEATPUMPS,
  DEFAULT_ENERGY_SPECS,
  DEFAULT_CUSTOMER_DATA,
} from './data/catalog';
import { calculateEnergySystem } from './engine/calculator';
import { Header } from './components/Header';
import { StepIndicator } from './components/StepIndicator';
import { StepHomeStart } from './components/StepHomeStart';
import { StepCurrentSituation } from './components/StepCurrentSituation';
import { StepBatteryAdvice } from './components/StepBatteryAdvice';
import { StepCustomerResult } from './components/StepCustomerResult';
import { StepOfficialReport } from './components/StepOfficialReport';
import { SettingsModal } from './components/SettingsModal';

export default function App() {
  const [currentStep, setCurrentStep] = useState<number>(0);
  const [scope, setScope] = useState<AdviceScope>('battery');
  const [energy, setEnergy] = useState<EnergySpecs>(DEFAULT_ENERGY_SPECS);
  const [customer, setCustomer] = useState<CustomerData>(DEFAULT_CUSTOMER_DATA);

  // Geselecteerde apparatuur (Standaard: 15.9 kWh HYXIPOWER)
  const [selectedBattery, setSelectedBattery] = useState<BatteryProduct>(HYXIPOWER_BATTERIES[1]);
  const [batteryActive, setBatteryActive] = useState<boolean>(true);
  const [selectedHeatPump, setSelectedHeatPump] = useState<HeatPumpProduct>(VAILLANT_HEATPUMPS[1]);
  const [heatPumpActive, setHeatPumpActive] = useState<boolean>(false);
  const [isManualBatterySelected, setIsManualBatterySelected] = useState<boolean>(false);

  // Modals status
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);

  // Centrale Rekenengine
  const calculation = useMemo(() => {
    return calculateEnergySystem(
      energy,
      selectedBattery,
      selectedHeatPump,
      batteryActive,
      heatPumpActive,
      scope
    );
  }, [energy, selectedBattery, selectedHeatPump, batteryActive, heatPumpActive, scope]);

  // Automatische aanpassing van de aanbevolen batterij o.b.v. het energieprofiel
  useEffect(() => {
    if (!isManualBatterySelected && calculation.recommendedBatteryTier) {
      const optimalBattery = HYXIPOWER_BATTERIES.find(
        (b) => b.capacityKwh === calculation.recommendedBatteryTier
      );
      if (optimalBattery && optimalBattery.capacityKwh !== selectedBattery.capacityKwh) {
        setSelectedBattery(optimalBattery);
      }
    }
  }, [calculation.recommendedBatteryTier, isManualBatterySelected, selectedBattery.capacityKwh]);

  // Scope switcher
  const handleSelectScope = (newScope: AdviceScope) => {
    setScope(newScope);
    if (newScope === 'battery') {
      setBatteryActive(true);
      setHeatPumpActive(false);
    } else if (newScope === 'heatpump') {
      setBatteryActive(false);
      setHeatPumpActive(true);
      if (energy.gasConsumptionM3 <= 0) {
        setEnergy((prev) => ({ ...prev, hasGas: true, gasConsumptionM3: 1550 }));
      }
    } else if (newScope === 'both') {
      setBatteryActive(true);
      setHeatPumpActive(true);
      if (energy.gasConsumptionM3 <= 0) {
        setEnergy((prev) => ({ ...prev, hasGas: true, gasConsumptionM3: 1550 }));
      }
    }
    setCurrentStep(1); // Direct naar stap 1 (nulmeting)
  };

  const handleResetAll = () => {
    setEnergy(DEFAULT_ENERGY_SPECS);
    setCustomer(DEFAULT_CUSTOMER_DATA);
    setSelectedBattery(HYXIPOWER_BATTERIES[1]);
    setBatteryActive(true);
    setSelectedHeatPump(VAILLANT_HEATPUMPS[1]);
    setHeatPumpActive(false);
    setScope('battery');
    setIsManualBatterySelected(false);
    setCurrentStep(0);
  };

  return (
    <div className="min-h-screen bg-[#f8faf9] text-slate-800 flex flex-col font-sans selection:bg-emerald-100 selection:text-emerald-900">
      {/* 1. Hoofdnavigatiebalk */}
      <Header
        currentStep={currentStep}
        onGoHome={() => setCurrentStep(0)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onReset={handleResetAll}
        onGoToReport={() => setCurrentStep(3)}
      />

      {/* 2. Stap-indicator */}
      <StepIndicator
        currentStep={currentStep}
        scope={scope}
        onSelectStep={(step) => setCurrentStep(step)}
      />

      {/* 3. Hoofdcontainer met de actieve stap */}
      <main className="flex-1 w-full min-w-0 mx-auto px-3 sm:px-6 lg:px-8 py-5 sm:py-8 transition-all">
        {currentStep === 0 && (
          <StepHomeStart onSelectScope={handleSelectScope} />
        )}

        {currentStep === 1 && (
          <StepCurrentSituation
            energy={energy}
            calculation={calculation}
            scope={scope}
            onChangeScope={(newScope) => handleSelectScope(newScope)}
            onChange={(updated) => setEnergy(updated)}
            onNext={() => setCurrentStep(2)}
          />
        )}

        {currentStep === 2 && (
          <StepBatteryAdvice
            energy={energy}
            calculation={calculation}
            scope={scope}
            allBatteries={HYXIPOWER_BATTERIES}
            selectedBattery={selectedBattery}
            onSelectBattery={(bat) => {
              setSelectedBattery(bat);
              setIsManualBatterySelected(true);
            }}
            batteryActive={batteryActive}
            onToggleBattery={(active) => setBatteryActive(active)}
            allHeatPumps={VAILLANT_HEATPUMPS}
            selectedHeatPump={selectedHeatPump}
            onSelectHeatPump={(hp) => setSelectedHeatPump(hp)}
            heatPumpActive={heatPumpActive}
            onToggleHeatPump={(active) => setHeatPumpActive(active)}
            onChangeEnergy={(updated) => {
              setEnergy(updated);
            }}
            onBack={() => setCurrentStep(1)}
            onNext={() => setCurrentStep(3)}
          />
        )}

        {currentStep === 3 && (
          <StepCustomerResult
            calculation={calculation}
            energy={energy}
            scope={scope}
            onUpdateEnergy={(updated) => setEnergy(updated)}
            allBatteries={HYXIPOWER_BATTERIES}
            selectedBattery={selectedBattery}
            onSelectBattery={(bat) => {
              setSelectedBattery(bat);
              setIsManualBatterySelected(true);
            }}
            batteryActive={batteryActive}
            onToggleBattery={(active) => setBatteryActive(active)}
            allHeatPumps={VAILLANT_HEATPUMPS}
            selectedHeatPump={selectedHeatPump}
            onSelectHeatPump={(hp) => setSelectedHeatPump(hp)}
            heatPumpActive={heatPumpActive}
            onToggleHeatPump={(active) => setHeatPumpActive(active)}
            onBack={() => setCurrentStep(2)}
            onNext={() => setCurrentStep(4)}
          />
        )}

        {currentStep === 4 && (
          <StepOfficialReport
            customer={customer}
            onUpdateCustomer={(updated) => setCustomer(updated)}
            energy={energy}
            calculation={calculation}
            selectedBattery={selectedBattery}
            batteryActive={batteryActive}
            selectedHeatPump={selectedHeatPump}
            heatPumpActive={heatPumpActive}
            onBack={() => setCurrentStep(3)}
          />
        )}
      </main>

      {/* 4. Footer */}
      <footer className="border-t border-slate-200/80 bg-white py-5 px-4 text-center text-xs text-slate-500 no-print">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="font-semibold text-slate-700">
            SolarFast Tafeladvies Rekenmodel
          </div>
          <div className="text-slate-500">
            HYXIPOWER Thuisbatterij • Vaillant aroTHERM Plus • EPEX Day-Ahead & Negatieve Prijzen
          </div>
        </div>
      </footer>

      {/* 5. Instellingen Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        energy={energy}
        onSave={(updated) => setEnergy(updated)}
        onResetAll={handleResetAll}
      />
    </div>
  );
}
